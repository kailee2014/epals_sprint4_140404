<?php
spl_autoload_register(include __DIR__ . '/autoload_function.php');
