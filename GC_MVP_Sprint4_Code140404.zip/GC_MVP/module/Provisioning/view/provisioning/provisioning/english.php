<?php 
$tra = array(
    'username'=>'username',
    'password'=>'password',
    'language'=>'language',
    'First Name'=>'First Name',
    'Last Name'=>'Last Name',
    'Gender'=>'Gender',
    'Email'=>'Email',
    'Vertify Email'=>'Vertify Email',
    'Username'=>'Username',
    'Password'=>'Password',
    'Vertify Password'=>'Vertify Password',
    'Birthday'=>'Birthday',
    'Your Title'=>'Your Title',
    'Country'=>'Country'

)
?>