<?php 
$tra = array(
    'username'=>'用户名',
    'password'=>'密码',
    'language'=>'语言',
    'First Name'=>'姓氏',
    'Last Name'=>'名字',
    'Gender'=>'性别',
    'Email'=>'邮箱',
    'Vertify Email'=>'邮箱确认',
    'Username'=>'用户名',
    'Password'=>'密码',
    'Vertify Password'=>'密码确认',
    'Birthday'=>'生日',
    'Your Title'=>'称号',
    'Country'=>'城市'
    
    
)
?>