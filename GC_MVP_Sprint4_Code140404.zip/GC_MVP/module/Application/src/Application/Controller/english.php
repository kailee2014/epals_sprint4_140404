<?php 
$tra = array(
    'username'=>'username',
    'password'=>'password',
    'language'=>'language'
)
?>