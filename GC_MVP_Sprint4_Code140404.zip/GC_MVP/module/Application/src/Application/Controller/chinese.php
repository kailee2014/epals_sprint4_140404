<?php 
$tra = array(
    'username'=>'用户名',
    'password'=>'密码',
    'language'=>'语言'
)
?>