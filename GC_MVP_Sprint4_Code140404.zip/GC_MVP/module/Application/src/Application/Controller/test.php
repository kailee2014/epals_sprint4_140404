<?php 
$tra = array(
    'dream'=>'梦'
)
?>